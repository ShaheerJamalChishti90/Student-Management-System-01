attendance_app/     #Folder
│
├── app.py                  ← Main Flask File
├── settings.json           ← Will be auto-created
├── static/         #Folder
│   └── logo.png          ← Logo
├── logs/           #Folder
│   └── attendance_'date'.xlxs      ← Will be auto-created
└── templates/      #Folder
    ├── form.html
    ├── success.html
    ├── already_logged_in.html
    ├── admin_settings.html
    ├── admin_logs.html
    └── error.html